import React from 'react';
import styles from './launch.module.css';

export default function ListeningScreen({ phase }) {
    return (
        <div className={styles.centerContainer}>
            <div className={styles.waveformContainer}>
                {[...Array(16)].map((_, i) => (
                    <div
                        key={i}
                        className={`${styles.bar} ${phase === 'analyzing' ? styles.analyzingBar : styles.listeningBar}`}
                        style={{ animationDelay: `${i * 0.08}s` }}
                    />
                ))}
            </div>
            <div className={styles.statusText}>
                {phase === 'listening' ? 'Listening…' : 'Analyzing voice…'}
            </div>
        </div>
    );
}
