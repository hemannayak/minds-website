import React from 'react';
import styles from './launch.module.css';

export default function AuthScreen({ phase }) {
    let textLines = [];

    if (phase === 'matched') {
        textLines = ['Voice pattern matched.'];
    } else if (phase === 'initializing') {
        textLines = ['MINDS Club of Data Science'];
    }

    return (
        <div className={styles.centerContainer}>
            <div className={styles.authText}>
                {textLines.map((line, i) => (
                    <div key={`${phase}-${i}`}>{line}</div>
                ))}
            </div>
        </div>
    );
}
