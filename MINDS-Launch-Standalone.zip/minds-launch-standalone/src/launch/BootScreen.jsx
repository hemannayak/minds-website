import React from 'react';
import styles from './launch.module.css';

export default function BootScreen() {
    return (
        <div className={styles.centerContainer}>
            <div className={styles.dataSpinner}>
                <div className={styles.spinnerCircle}></div>
            </div>
        </div>
    );
}
