import React, { useState, useEffect } from 'react';
import styles from './launch.module.css';
import BootScreen from './BootScreen';
import ListeningScreen from './ListeningScreen';
import AuthScreen from './AuthScreen';
import LogoFormation from './LogoFormation';
import ReadyLaunchScreen from './ReadyLaunchScreen';

const PHASES = ['boot', 'ready-launch', 'listening', 'analyzing', 'matched', 'initializing', 'logo'];

export default function LaunchPage() {
    const [phase, setPhase] = useState('boot');

    const speak = (text, isCinematic = false) => {
        if (!window.speechSynthesis) return;

        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);

        // Find a high-quality, natural-sounding voice
        const voices = window.speechSynthesis.getVoices();

        // Try to find specific premium voices or fallback to the first English voice
        const preferredVoice = voices.find(
            voice =>
                voice.name.includes("Premium") ||
                voice.name.includes("Enhanced") ||
                voice.name.includes("Samantha") || // Apple's good female voice
                voice.name.includes("Siri") ||
                (voice.name.includes("Google") && voice.lang.includes("en"))
        ) || voices.find(voice => voice.lang.startsWith("en"));

        if (preferredVoice) {
            utterance.voice = preferredVoice;
        }

        if (isCinematic) {
            // Slower, slightly deeper, more dramatic tone for the initial prompt
            utterance.rate = 0.85;
            utterance.pitch = 0.8;
            utterance.volume = 1;
        } else {
            // Natural, conversational settings for the rest
            utterance.rate = 1.05;
            utterance.pitch = 1.0;
            utterance.volume = 1;
        }

        window.speechSynthesis.speak(utterance);
    };

    const advancePhase = () => {
        setPhase((prev) => {
            const idx = PHASES.indexOf(prev);
            if (idx !== -1 && idx < PHASES.length - 1) {
                return PHASES[idx + 1];
            }
            return prev;
        });
    };

    useEffect(() => {
        return () => {
            window.speechSynthesis.cancel();
        };
    }, []);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.key.toLowerCase() === 'l' || e.key === ' ' || e.key === 'Enter') {
                advancePhase();
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    useEffect(() => {
        let timer;
        if (phase === 'boot') {
            timer = setTimeout(() => setPhase('ready-launch'), 1500);
        } else if (phase === 'ready-launch') {
            speak('Are you ready for launch!', true);
        } else if (phase === 'analyzing') {
            speak('Analyzing voice…');
        } else if (phase === 'matched') {
            speak('Voice pattern matched.');
        } else if (phase === 'initializing') {
            speak('MINDS Club of Data Science');
        }

        return () => clearTimeout(timer);
    }, [phase]);

    return (
        <div
            className={`${styles.launchContainer} ${phase === 'logo' ? styles.darkTheme : styles.lightTheme}`}
            onClick={advancePhase}
            style={{ cursor: 'pointer' }}
        >
            <div className={styles.gridOverlay}></div>
            <svg className={styles.lineGraph} viewBox="0 0 1000 1000" preserveAspectRatio="none">
                <path
                    className={styles.lineGraphPath}
                    d="M0,500 L100,450 L200,600 L300,300 L400,550 L500,400 L600,650 L700,350 L800,500 L900,400 L1000,500"
                />
                <path
                    className={styles.lineGraphPath2}
                    d="M0,600 L150,550 L250,700 L450,400 L550,650 L750,500 L850,550 L1000,450"
                />
            </svg>
            <div className={styles.contentWrapper}>
                {phase === 'boot' && <BootScreen />}
                {phase === 'ready-launch' && <ReadyLaunchScreen />}
                {(phase === 'listening' || phase === 'analyzing') && <ListeningScreen phase={phase} />}
                {['matched', 'initializing'].includes(phase) && <AuthScreen phase={phase} />}
                {phase === 'logo' && <LogoFormation />}
            </div>
        </div>
    );
}
