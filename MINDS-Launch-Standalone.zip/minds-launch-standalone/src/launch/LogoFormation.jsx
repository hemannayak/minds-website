import React from 'react';
import styles from './launch.module.css';

export default function LogoFormation() {
    return (
        <div className={styles.centerContainer}>
            <div className={styles.videoContainer}>
                <video
                    src="/Logo%20Launch%20Video%20.mp4"
                    autoPlay
                    muted
                    playsInline
                    className={styles.videoElement}
                />
            </div>
        </div>
    );
}
