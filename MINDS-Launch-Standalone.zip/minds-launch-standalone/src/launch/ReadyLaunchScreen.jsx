import React from 'react';
import styles from './launch.module.css';

export default function ReadyLaunchScreen() {
    return (
        <div className={styles.centerContainer}>
            <div className={styles.authText}>
                Are you ready for launch!
            </div>
        </div>
    );
}
