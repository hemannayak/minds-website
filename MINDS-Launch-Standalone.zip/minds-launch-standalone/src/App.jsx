import React from 'react'
import LaunchPage from './launch/LaunchPage'

function App() {
    return <LaunchPage />
}

export default App
